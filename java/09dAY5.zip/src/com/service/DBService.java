package com.service;

import com.dao.MySQLDAO;

public class DBService {

    MySQLDAO dao;//기본값 null
    
    public void setDAO(MySQLDAO dao){
        this.dao = dao;
        this.dao.ConnectMySQL();
    }
    
    public void insert(){
        dao.insert();
    }
}
