package com.dao;

public class OracleDAO {
    public void connectOracle(){
        System.out.println("OracleDAO.connect=========");
    }

    public void insert(){
        System.out.println("OracleDAO.insert==========");
    }
}
