package com.dao;

public interface DBDAO {
    
    public abstract void connect();
    public abstract void insert();
}
